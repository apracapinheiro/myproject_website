# Django Apps

In this directory you can place Django Apps that for some reason cannot be installed from the Python Package Index or version controls.

Some examples:

- Patched apps
- Private apps
- Legacy versions

Then use this README file to describe what apps and versions you are using here.

| Django App | Version | Description | Source URL |
|------------|---------|-------------|------------|
|            |         |             |            |
|            |         |             |            |
|            |         |             |            |