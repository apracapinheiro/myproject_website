# Django MyProject

This is a boilerplate for a scalable Django project. To use it, just download the source code and globally replace "myproject" with a meaningful project name. Then start building your apps.