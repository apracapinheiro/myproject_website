from ._base import *

DEBUG = False
ALLOWED_HOSTS = [
    "*",
]
